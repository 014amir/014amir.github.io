<?php
include("header.php");
if(!isset($_SESSION['username'])){
  header("location: login.php");}
?>

<div id='worktext'>
<noindex><div id="ad_c1"><style>
.adslot { height: 280px; }
@media(min-width: 500px) { .adslot { height: 280px; } }
@media(min-width: 800px) { .adslot { height: 280px; } }
</style>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle adslot"
     style="display:block"
     data-ad-client="ca-pub-4310170390019457"
     data-ad-slot="5336081542"
	 data-full-width-responsive="false"
     </ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>		</div></noindex><DIV TYPE=HEADER>
	</DIV>
<div class="container">
<P ALIGN=CENTER STYLE="margin-bottom: 0cm"><B>Examination questions and answers in Law</B></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><B>Question
1. State: concept, features, functions.</B></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><B>Ответ:</B>
<U><B>The stage</B></U>is a special non-political 
organization, which has the apparatus of management
 and suppression, forcing by its command.</P>
<P ALIGN=JUSTIFY STYLE="text-indent: 1.27cm; margin-bottom: 0cm">
In science, many points of view have been formed,
 each of which in its own way describes the state,
  its role and purpose in the life of society.</P>
<P ALIGN=JUSTIFY STYLE="margin-right: 0.1cm; text-indent: 1.27cm; margin-bottom: 0cm; background: #ffffff">
First of all, it should be noted that for a long
 time the state was identified with the society
  itself. Ancient philosophers considered the 
state as a communication of free people seeking
 a good life.</P>
<P ALIGN=JUSTIFY STYLE="margin-right: 0.06cm; text-indent: 1.27cm; margin-bottom: 0cm; background: #ffffff">
Representatives of the contractual theory defined 
the state as a Union of people living in a certain
 territoryand subject to Supreme authority.</P>
<P ALIGN=JUSTIFY STYLE="margin-right: 0.04cm; text-indent: 1.27cm; margin-bottom: 0cm; background: #ffffff">
Marxist-Leninist science focused exclusively
 on the class nature of the state. On this basis,
 the state was understood as an organization of 
 political power of the economically dominant class,
 and in view of the priority of Marxist-Leninist
 doctrine in the literature, views on the concept
 and essence of the state were presented exclusively 
in the class tone.</P>
<P ALIGN=JUSTIFY STYLE="margin-right: 0.02cm; text-indent: 1.27cm; margin-bottom: 0cm; background: #ffffff">
When Marxist-Leninist ideology collapsed, 
scientists critically comprehended the
 legacy of the past, as well as taking
  into account significant changes
public life, began to define the state
 as a political organization of society,
  ensuring its unity and integrity.</P>
<P ALIGN=JUSTIFY STYLE="text-indent: 1.27cm; margin-bottom: 0cm; background: #ffffff">
In the educational literature, 
you can find the definition of
 the state as a single political
  organization of society, which 
  extends its power to the entire 
  territory of the country and its
   population, has a special apparatu
for all, and has sovereignty.</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.03cm; text-indent: 1.24cm; margin-top: 0.03cm; margin-bottom: 0cm; background: #ffffff">
<U><B>Signs of the state</B></U><U>:</U></P>
<P ALIGN=JUSTIFY STYLE="margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff; widows: 0; orphans: 0">
- Territorial division – administrative and state borders;</P>
<P ALIGN=JUSTIFY STYLE="margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff; line-height: 150%; widows: 0; orphans: 0">
- Tax collection;</P>
<P ALIGN=JUSTIFY STYLE="margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff; line-height: 150%; widows: 0; orphans: 0">
- The presence of the control apparatus;</P>
<P ALIGN=JUSTIFY STYLE="margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff; line-height: 150%; widows: 0; orphans: 0">
- Noma creativity;</P>
<P ALIGN=JUSTIFY STYLE="margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff; line-height: 150%; widows: 0; orphans: 0">
- An apparatus of coercion;</P>
<P ALIGN=JUSTIFY STYLE="margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff; widows: 0; orphans: 0">
-Sovereignty – independence of state power from other States; 
</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.03cm; margin-right: 0.03cm; text-indent: 1.24cm; margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff">
<U><B>The functions of the state</B></U>
are objectively necessary
 directions in the activities
  of the state, expressing
its essence and social purpose.</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.02cm; margin-right: 0.02cm; text-indent: 1.25cm; margin-top: 0.01cm; margin-bottom: 0cm; background: #ffffff">
The functions of a state may be
 classified on various grounds.
  Depending on the sphere of
   public life, internal and 
external functions are distinguished
. The internal functions include 
economic, social, cultural and 
educational functions; the function
 of financial control; the function
  of taxation, etc.</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.02cm; margin-right: 0.03cm; text-indent: 1.25cm; margin-bottom: 0cm; background: #ffffff">
External recognized such functions
 as defense of the country (depending 
on the nature of the state, this may
 be a function of aggression); 
environmental function; world
 order support function.</P>
<P ALIGN=JUSTIFY STYLE="margin-right: 0.02cm; text-indent: 1.27cm; margin-top: 0.02cm; margin-bottom: 0cm; background: #ffffff">
According to the duration
 of the functions are divided
  into permanent and temporary
  . Permanent functions are carried 
  out at all stages of the development
   of society. These include the economic
    function, the function of law enforcement.
     The allocation of time functions
 it is associated with the emergence of 
emergency situations, i.e. they are aimed
 at solving important, but at the same time 
temporary tasks. For example, the function 
of elimination of consequences of any accident.</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.02cm; margin-right: 0.12cm; text-indent: 1.25cm; margin-bottom: 0cm; background: #ffffff">
There are legal and organizational
 forms of the state functions. The
  legal form consists in the adoption
   of various legal acts. It includes:
    law-making, law enforcement, law enforcement.</P>
<P ALIGN=JUSTIFY STYLE="margin-right: 0.1cm; text-indent: 1.27cm; margin-bottom: 0cm; background: #ffffff">
Organizational form
performing state functions
cycle covers
preparatory work not entailing
legal
consequences. But from this its value is not
falls as given
the activity creates the necessary
conditions for successful implementation
tasks of the state.</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><B>Вопрос
2. The origin of state and law
essence of law.</B></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><B>Answer</B><B>:</B><B>
</B><U><B>Causes of origin
of the state</B></U><U><B>:</B></U></P>
<P ALIGN=JUSTIFY STYLE="text-indent: 1.27cm; margin-bottom: 0cm">
Socio-economic theory of the origin of the state.</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><B>1</B><U><B>.</B></U><U>
Economic reasons: </U> 1) Neolithic
revolution ensuring the transition from
gathering to producing economy.
2) three major divisions of labor</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm">-
appearance of cattle breeding</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm">-
separation of handicrafts from agriculture</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm">3) labor productivity
 growth and the appearance of surplus
</P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm"><U><B>2.</B></U>
Social reasons: </ u> 1) the disintegration of the genus, the emergence of the family.
 2) contradiction in society. 3) stratification of society
(the emergence of classes). 
</P>
<P ALIGN=JUSTIFY STYLE="text-indent: 1.27cm; margin-bottom: 0cm">
The term “law” in modern legal science is used in several meanings. So right
called social legal claims
people (for example, the right of peoples to
self-determination); officially
recognized opportunities (eg right
to health care);
system of legal norms (objective
right); aggregate
all legal phenomena (legal system).</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.02cm; margin-right: 0.07cm; text-indent: 1.25cm; margin-bottom: 0cm; background: #ffffff">
Most significant in history
political and legal thoughts are
interpretations of the law given by representatives
natural, psychological,
historical, positivist,
sociological theory of law
philosophy of law and Marxism.</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.02cm; margin-right: 0.07cm; text-indent: 1.25cm; margin-bottom: 0cm; background: #ffffff">
<U><B>Law-</B></U>
is a system of generally binding rules and
standards established and protected
by the state.</P>
<P ALIGN=JUSTIFY STYLE="margin-left: 0.02cm; margin-right: 0.07cm; text-indent: 1.25cm; margin-bottom: 0cm; background: #ffffff">
<p>

</p>

</div>

<?php
include("footer.php");
?>