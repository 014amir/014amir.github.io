 <!-- start footer Area -->
            <footer class="footer-area section-gap">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5 col-md-6 col-sm-6">
                            <div class="single-footer-widget">
                                <p class="footer-text">
								Address: Kazakhstan, Astana, st. Satbayeva 2, Almaty district, Nur-Sultan 010000
								</p>
								<p>Copyright &copy; All rights reserved | 2019</p>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-6 col-sm-6">
                            <div class="single-footer-widget">
                         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2502.431083518751!2d71.466876615185!3d51.15584154416825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4245816a9d03e2cf%3A0xf45162f9cbe14e1!2z0JrQsNC30LDRhdGB0YLQsNC90YHQutC40Lkg0YTQuNC70LjQsNC7INCc0JPQoyDQuNC8LiDQnC7Qki4g0JvQvtC80L7QvdC-0YHQvtCy0LAgLSDQldCd0KMg0LjQvC4g0JzRg9GF0LDQvNC80LXQtNCwINCa0LDQsdC00YvRgdCw0LvRj9C8!5e0!3m2!1sru!2skz!4v1554261204343!5m2!1sru!2skz" width="450" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6 col-sm-6 social-widget">
                            <div class="single-footer-widget">
                                <h4>Follow Me</h4>
                                <div class="footer-social d-flex align-items-center">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>	
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- End footer Area -->		
		</body>
	</html>